import numpy as np
import csv
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets
import time
from sklearn.decomposition import PCA
import pandas as pd
import random

def loadDataSet(filename, trainingSet=[], targetSet=[]):
	with open(filename, 'rb') as csvfile:
	    lines = csv.reader(csvfile)
	    csvfile.readline()
	    dataset = list(lines)

	    for x in range(len(dataset)):
	        for y in range(0,784):
	            dataset[x][y] = int(dataset[x][y])
	        trainingSet.append(dataset[x][1:785])
	    	targetSet.append(dataset[x][:1][0])

def loadTestSet(filename, testSet=[]):
	with open(filename, 'rb') as csvfile:
	    lines = csv.reader(csvfile)
	    csvfile.readline()
	    dataset = list(lines)

	    for x in range(len(dataset)):
	        for y in range(784):
	            dataset[x][y] = int(dataset[x][y])
	        testSet.append(dataset[x])

def main():
	inicio = time.time()
	trainingSet=[]
	targetSet=[]
	testSet = []

	#loadDataSet('train.csv',trainingSet, targetSet)
	#loadTestSet('test.csv',testSet)

	
	dataset = pd.read_csv("train14x14.csv")
	targetSet = dataset[[0]].values.ravel()
	trainingSet = dataset.iloc[:,1:].values
	testSet = pd.read_csv("test14x14.csv").values
	dataset = pd.read_csv("trainAmpliado14x14.csv")
	targetSetA = dataset[[0]].values.ravel()
	trainingSetA = dataset.iloc[:,1:].values
	
	'''
	setCompleto = np.concatenate((trainingSet,trainingSetA[:42000]))
	
	setCompleto = np.concatenate((trainingSet,testSet))

	u,s,v = np.linalg.svd(setCompleto,0)

	trainingSet = u[:42000,:168]

	testSet = u[42000:,:168]
	
	targetSet = np.concatenate((targetSet,targetSetA[:42000]))
	'''

	indices=[]
	for i in range(0,252000,6):
		indice = random.randint(i,i+5)
		indices.append(indice)
	
	trainA =[]
	targetA = []
	for i in indices:
		trainA.append(trainingSetA[i])
		targetA.append(targetSetA[i])

	trainA = np.matrix(trainA)
	targetA = np.array(targetA)

	trainingSet = np.concatenate((trainingSet,trainA))

	targetSet = np.concatenate((targetSet,targetA))

	print trainingSet.shape

	'''
	dataset = pd.read_csv("trainAmpliado.csv")
	targetSetA = dataset[[0]].values.ravel()
	trainingSetA = dataset.iloc[:,1:].values

	indices=[]
	for i in range(42000):
		indice = random.randint(0,252000)
		if inidice not in indices:
			inidices.append(inidice)
	
	for inidice in indices:
	'''

	'''
	dataset = pd.read_csv("train.csv")
	targetSet = dataset[[0]].values.ravel()
	trainingSet = np.loadtxt("fooa.csv")
	testSet = np.loadtxt("testReduc.csv")
	'''
	
	print 'tardo ' + str(int(time.time() - inicio)) + ' segundos en cargar los datos'

	inicio = time.time()

	X = trainingSet  
	y = targetSet

	print 'KNeighborsClassifier'
	clf = neighbors.KNeighborsClassifier(n_neighbors=4 , weights='distance',algorithm='ball_tree' ,n_jobs=-1)
	clf.fit(X,y)

	print 'buscando predicciones'
	predic = clf.predict(testSet)
	
	'''
	correct = 0
	for x in range(len(predic)):
		if predic[x] == targetSet[x]: correct+=1
		print 'prediccion: ' + str(predic[x]) + ' verdadero: ' + str(targetSet[x]) + str()
	print 'Precision: ' + str(float(correct)/float(len(predic)) * 100.0)
	'''
	
	print 'terminaron las predicciones'

	fin = time.time()
	print 'tardo :' + str(float(fin - inicio)/60.0) + ' minutos'

	with open('predicciones.csv', 'w') as csvfile:
	    fieldnames = ['ImageId', 'Label']
	    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
	    writer.writeheader()
	    for i in range(len(predic)):
	    	writer.writerow({'ImageId': str(i+1), 'Label': str(predic[i])})
	
main()
